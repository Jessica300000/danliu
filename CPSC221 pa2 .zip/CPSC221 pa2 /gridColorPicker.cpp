#include "gridColorPicker.h"

gridColorPicker::gridColorPicker(HSLAPixel gridColor, int gridSpacing)
{

    /* Your code here! */
    color = gridColor;
    spacing = gridSpacing;
}

HSLAPixel gridColorPicker::operator()(int x, int y)
{

    /* Your code here! */
    if (x%spacing == 0 || y%spacing == 0) {
        return color;
    } else {
        HSLAPixel ret;
        ret.h = 0.; 
        ret.s = 0.; 
        ret.l = 1.;
        return ret;
    }

}
